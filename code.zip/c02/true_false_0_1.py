# true_0_1.py
if 0: print('0 is True')
else: print('0 is False') # 0 is False

if 0.0: print('0.0 is True')
else: print('0.0 is False') # 0.0 is False

if 1: print('1 is True')
else: print('1 is False') # 1 is True

if {}: print('{} is True')
else: print('{} is False') # 1 is False
