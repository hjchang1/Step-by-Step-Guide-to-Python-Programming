# change_print_file_arg.py
x = [1, 2, 3, 4]
y = '파이썬 출력 테스트'

fo = open('out.txt', 'w') # out.txt 파일을 쓰기 모드로 연다
print(x, file=fo)
print(y, file=fo)
fo.close() # out.txt 파일을 닫는다.
