# change_stdout.py
import sys

sys.stdout = open('out.txt', 'w')
print('Hello!')
print('Beautiful Python!')

sys.stdout.close()
