# cmd_sum.py 프로그램
import sys

sum = 0
if (len(sys.argv) != 3):
    print('Usage: python sum <정수1> <정수2>')
    sys.exit(1)
else:
    num1 = int(sys.argv[1])
    num2 = int(sys.argv[2])

    i = num1;
    while (i <= num2):
        sum = sum + i
        i = i + 1

print(sys.argv[0])
print(sys.argv[1], '+ ... +', sys.argv[2], '=', sum)



        
