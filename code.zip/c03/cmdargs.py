# cmdargs.py 파일
import sys

print('명령행 인자의 수: ', len(sys.argv))
print ('명령행 인자들의 목록: ', str(sys.argv))
