# file_pointer_test.py
f = open('foo.txt', 'wt') # foo.txt 파일을 만든다.
f.write('This is line one.\nThis is line two.\nPython is great!\n')
f.close()

# foo.txt 파일을 연 직후의 파일 포인터 값은 0이다.
f = open('foo.txt', 'rt')
print('파일 포인터 위치: ', f.tell()) # 0
contents1 = f.read()

# foo.txt파일을 끝까지 읽은 직후의 파일 포인터 값은 EOF의 색인이다.
print('파일 포인터 위치: ', f.tell()) # 56
contents2 = f.read()
print('contents2: [{}]\n'.format(contents2)) # 더 이상 읽을 것이 없다

f.seek(0)
print('파일 포인터 위치: ', f.tell())
contents3 = f.read()
print('contents3: [{}]\n'.format(contents3))
