# open_foo_txt.py
fo = open('foo.txt', 'wb')
print ('Name of the file: ', fo.name) # foo.txt 출력
print ('Closed or not : ', fo.closed) # False 출력
print ('Opening mode : ', fo.mode) # wb 출력
fo.close()
