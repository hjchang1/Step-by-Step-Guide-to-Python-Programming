# open_hosts_file.py
f = open('C:/Windows/System32/drivers/etc/hosts') # 파일 열기
contents = f.read() # 파일 객체 f를 이용하여 파일 내용 읽기
print(contents) # 읽어낸 파일 내용 출력하기
f.close() # 파일 객체 닫기
