# pickle_dump_demo.py
import pickle

x = 123
y = 'Python'
z = [1, 2, 3]

fp = open('x.bin', 'wb')
pickle.dump(x, fp)
pickle.dump(y, fp)
pickle.dump(z, fp)

fp.close()
