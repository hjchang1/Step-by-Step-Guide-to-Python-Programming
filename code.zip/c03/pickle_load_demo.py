# pickle_load_demo.py
import pickle

fp = open('x.bin', 'rb')
x1 = pickle.load(fp)
y1 = pickle.load(fp)
z1 = pickle.load(fp)
fp.close()

print(x1, y1, z1)
