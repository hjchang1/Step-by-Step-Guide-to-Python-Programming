# read_foo_txt.py
fo = open('foo.txt', 'r')
contents = fo.read(10)
print('contents: ', contents) 

# Close opened file
fo.close()
