# write_foo_txt.py
fo = open('foo.txt', 'w') # Open a file
fo.write('This is line one.\nThis is line two.\nPython is great!\n')
# Close opened file
fo.close()
