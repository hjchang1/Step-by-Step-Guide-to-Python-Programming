# factorial.py
def factorial(n):
    ''' 
    이 것은 재귀법을 사용하는
    factorial() 함수에 대한
    다중 줄 주석이다.
    '''
    
    if n == 1: # 이것은 한줄 주석이다.
        return 1
    else:
        return n * factorial(n-1) # n! = n * (n-1)!

factorial(5) # 이것도 한줄 주석이다.
