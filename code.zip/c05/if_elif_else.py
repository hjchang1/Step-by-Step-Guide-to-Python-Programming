# if_elif_else.py
score = 80

if (score > 80):
    grade = 'A'
elif (score > 70):
    grade = 'B'
elif (score > 60):
    grade = 'C'
else:
    grade = 'D'

print('grade =', grade)
