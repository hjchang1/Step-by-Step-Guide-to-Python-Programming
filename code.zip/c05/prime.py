# prime.py 사용자로부터 입력받은 숫자 num이 소수인가를 판정하는 프로그램
num = int(input('2 이상의 정수를 입력하세요: '))
is_prime = True;

for i in range(2, num):
    if ((num % i) == 0): # 자신보다 작은 숫자로 나누어지는지 검사
        print('{}은(는) {} x {} 이므로'.format(num, i, num//i), end = ' ')
        is_prime = False
        break
      
if (is_prime):
    print('{}은(는) 소수입니다.'.format(num))
else:
    print('소수가 아닙니다.')
