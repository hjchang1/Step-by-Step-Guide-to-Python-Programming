# python_break.py
s = 'Python!'

found = False
i = 0
while(True):
    if (len(s) <= i):
        break        
    if (s[i] == 'x'):
        found = True
    i = i + 1
    
print(found)
