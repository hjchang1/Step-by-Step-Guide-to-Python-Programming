# range_factorial.py
i = int(input('정수: '))
r = 1
for t in range(1, i+1):
    r = r * t
    
print('factorial({}) = {}'.format(i, r))
