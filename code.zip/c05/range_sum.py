# range_sum.py
sum = 0
for i in range(1, 101):
    sum = sum + i

print(sum)
