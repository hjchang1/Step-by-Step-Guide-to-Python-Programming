# while_factorial.py
i = int(input('정수: '))
t = 1
r = 1

while (t <= i):
    r = r * t
    t = t + 1

print('factorial({}) = {}'.format(i, r))
