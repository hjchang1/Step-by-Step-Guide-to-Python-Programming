# count_vowels.py
def count_vowels(s):
    s_lower = s.lower() # 소문자 문자열로 변환
    vowels_count = {'a':0, 'e':0, 'i':0, 'o':0, 'u':0}

    for c in s_lower:
        if c in vowels_count.keys():
            vowels_count[c] = vowels_count[c] + 1

    return vowels_count

s = 'This is a book. That is a desk.'
print('Vowels {} in\n\'{}\''.format(count_vowels(s), s))
