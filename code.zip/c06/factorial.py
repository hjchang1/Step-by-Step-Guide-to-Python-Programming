# factorial.py
def factorial(n):
    def facto(n):
        if (n == 1):
            return 1
        else:
            return (n * facto(n-1))
        
    if not (isinstance(n, int) & (n > 0)):
        print('Oops, not a positive integer!')
        return None

    return facto(n)

print(factorial(5))
