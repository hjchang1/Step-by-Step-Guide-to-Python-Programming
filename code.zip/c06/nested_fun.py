# nested_fun.py
def outer(num):
    x = 100 # outer의 지역 변수 x
    def inner(n):
        r = n * x # inner()의 지역 변수 r
        return r

    r = inner(num) + 1 # outer()의 지역 변수 r
    return r

print(outer(5)) # (100 * 5) + 1
