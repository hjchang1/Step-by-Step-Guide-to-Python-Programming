# range_sum.py 
def range_sum(x): # 0 + 1 + ... + x 의 계산   
    sum_x = 0 
    for c in range(x + 1):
        sum_x = sum_x + c

    return sum_x

print(range_sum(10)) # 55
print(sum_x) # error
