# range_sum_method.py
class X:
    def range_sum(self, x): # function parameter self and x
        sum_x = 0 # local variable sum
        for c in range(x + 1): # local variable i
            sum_x = sum_x + c

        return sum_x

x1 = X()
print(x1.range_sum(10))
