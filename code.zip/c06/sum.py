# sum.py
def sum(x, y):
    '''
    이 함수는 x와 y의 합을 
    반환한다.
    '''
    sum = x + y
    return sum
