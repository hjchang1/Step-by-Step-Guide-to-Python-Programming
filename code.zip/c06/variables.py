# variables.py
x = 100 # 전역 변수 x

def f(m):
    print('x =', x) # 전역 변수 x의 값을 출력
    return x * m

def g():
    x = 200 # 함수 g()의 지역 변수 x의 정의
    print('x =', x) # 함수 g()의 지역 변수 x를 출력 
    return x
    
g()
f(5)
