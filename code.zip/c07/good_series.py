# modified_series.py
def geometric(n, r):
    ''' 공비가 r인 등비 수열을 담은 리스트를 반환한다. 
    '''
    e = 1
    result = [e]
    while True:
        e = r * e
        if (e > n):
            break
        result.append(e)
        
    return result

def fibonacci(n):
    ''' n까지의 피보나치 수열을 담은 리스트를 반환한다 '''
    result = []
    a, b = 0, 1
    while (b < n):
        result.append(b)
        a, b = b, a + b
    return result

# geometric() 함수와 fibonacci() 함수가 잘 동작하는지 테스트 해본다.
if __name__ == '__main__':
    x = 100
    print(geometric(x, 2)) # [1, 2, 4, 8, 16, 32, 64]
    print(fibonacci(x)) # [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
