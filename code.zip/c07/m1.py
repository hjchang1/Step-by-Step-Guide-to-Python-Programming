# m1.py
print('(1) 현재 수행 모듈:', __name__)
