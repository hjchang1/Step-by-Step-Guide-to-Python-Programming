# m2.py
print('(2) 현재 수행 모듈:', __name__) # import m1 문 수행하기 직전
import m1

print('(3) 현재 수행 모듈:', __name__) # import m1 문 수행한 직후 
