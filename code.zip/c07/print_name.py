# print_name.py
print('현재 수행 모듈의 이름:', __name__)
