# sample/a.py
def bar():
    print('sample 패키지의 모듈 a의 함수 bar()가 호출됨')

print('파일 모듈 a.py가 수행됨')
