# sample/b.py
def foo():
    print('sample 패키지의 모듈 b의 함수 foo()가 호출됨')
