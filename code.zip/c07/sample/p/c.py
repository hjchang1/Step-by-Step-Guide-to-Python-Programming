# sample/p/c.py
z = 3
_test = 'Software is a team sports.'

def deep():
    print('sample.p.c 모듈의 함수 deep()이 호출됨')
