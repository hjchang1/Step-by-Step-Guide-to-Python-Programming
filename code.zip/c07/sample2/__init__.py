# sample2/__init__.py
x = 1
print('sample2/__init__.py executed!')

