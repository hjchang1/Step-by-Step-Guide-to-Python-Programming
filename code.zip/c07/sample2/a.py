#-*- coding: utf-8 -*-
def bar():
    print('모듈 a의 함수 bar() 호출됨')
