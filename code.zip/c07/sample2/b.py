#-*- coding: utf-8 -*-
def foo():
    print('모듈 b의 함수 foo() 호출됨')
