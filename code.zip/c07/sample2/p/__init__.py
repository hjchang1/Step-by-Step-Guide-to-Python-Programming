# sample2/p/__init__.py
y = 17
_p = 18
print('sample2/p/__init__.py executed!')
