# use_series.py
import series

# series 모듈의 fibonacci() 함수를 호출한다.
r = series.fibonacci(1000)
print(r)
