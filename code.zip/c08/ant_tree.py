# Ant_Tree.py
class Ant:
    def __init__(self):
        self.body_temperature = 10 # 개미 객체의 체온을 표현하는 인스턴스 변수
        self.speed = 5 # 개미 객체의 이동 속도를 표현하는 인스턴스 변수 
        print('Ant 객체의 생성자가 호출됨')

class Tree:
    def __init__(self, height):
        self.height = height # Tree 객체의 높이를 표현하는 인스턴스 변수
        print('높이가 {}인 Tree 객체가 생성됨'.format(height))
