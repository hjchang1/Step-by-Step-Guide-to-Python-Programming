# class_variable.py
class Tree:
    total_trees = 0 # Tree 인스턴스의 총 수를 표현하기 위한 클래스 변수

    def __init__(self):
        Tree.total_trees = Tree.total_trees + 1  # <클래스>.<클래스 변수>

tree1 = Tree()
tree2 = Tree()

print('Tree 인스턴스의 총 수:', Tree.total_trees) # <클래스>.<클래스 변수>
print('Tree 인스턴스의 총 수:', tree1.total_trees) # <인스턴스>.<클래스 변수>
print('Tree 인스턴스의 총 수:', tree2.total_trees) # <인스턴스>.<클래스 변수>
