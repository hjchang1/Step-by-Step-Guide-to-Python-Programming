# cup.py 
class Cup:
    __price = 100 # __로 시작하면 name mangling 대상
    
    def __init__(self, color):
        self._color = color # _로 시작하면 서브 클래스에서만 사용을 권장
        self.__content = None  # __로 시작하면 name mangling 대상
        print(self.__content) # None

    def fill(self, beverage):
        self.__content = beverage

    def __empty(self):
        self.__content = None

cup1 = Cup('red')
cup1.fill('black tee')

#print(cup1.__content) # 오류
print(cup1._Cup__content) # OK

#print(cup1.__price) # 오류
print(cup1._Cup__price) # OK

#cup1.__empty()
cup1._Cup__empty()
