# del_animals.py
class Animal:
    def __init__ (self, name):
        self.name = name
        print('객체 %s이 생성되었다.' % self.name)
        
    def __del__(self):
        print('객체 %s이 소멸된다.' % self.name)

a1 = Animal('a1')
a2 = Animal('a2')
a3 = a2

del a1 # a1이 참조하는 객체 소멸
del a2
del a3 # a3가 참조하는 객체 소멸
