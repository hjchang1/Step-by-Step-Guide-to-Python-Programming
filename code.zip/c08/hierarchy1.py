# hierarchy1.py
class Mammal:
    pass

class Fish:
    pass

class Cat(Mammal):
    pass

class Dog(Mammal):
    pass

class Whale(Mammal):
    pass
