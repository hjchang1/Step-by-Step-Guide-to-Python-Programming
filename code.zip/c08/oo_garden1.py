# oo_garden1.py
class Sun:
    def __init__(self):
        self.angle = 0  # 태양의 각도(0~180도)를 표현하는 인스턴스 변수
        print('Sun 객체의 생성자가 호출됨')

class Ant:
    def __init__(self):
        self.body_temperature =10 # 개미의 체온을 표현하는 인스턴스 변수
        self.speed = 5 # 개미의 이동 속도를 표현하는 인스턴스 변수 
        print('Ant 객체의 생성자가 호출됨')

class Tree:
    def __init__(self, height):
        self.height = height # Tree 객체의 높이를 표현하는 인스턴스 변수
        print('높이가 {}인 Tree 객체가 생성됨'.format(height))

sun1 = Sun() # Sun 클래스의 __init__(self)가 호출된다.
ant1 = Ant() # Ant 클래스의 __init__(self)가 호출된다.
ant2 = Ant() # Ant 클래스의 __init__(self)가 호출된다.
tree1 = Tree(500) # Tree 클래스의 __init__(self, height)가 호출된다.
