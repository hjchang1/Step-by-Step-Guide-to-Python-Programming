# oo_garden2.py
class Sun:
    # 정원의 모든 객체들의 리스트를 표현하는 class 변수   
    things_in_garden = []

    @classmethod
    def print_things(cls):
        ''' 정원에 존재하는 모든 객체들의 이름을 출력함 '''
        print('Things in the garden:', end = ' ')
        len_of_things = len(cls.things_in_garden)
        for i in range(0, len_of_things-1):
            print(cls.things_in_garden[i].name, end = ', ')
        print(cls.things_in_garden[len_of_things-1].name)

    def circle(self):
        ''' sun 객체가 동에서 떠서 서쪽으로 질 때까지
            정원의 모든 객체들에게 햇빛 메시지 보냄
        '''
        Sun.print_things()
        for angle in range(0, 181):
            print('\n---------- Sun angle: {} ---------- '.format(angle))
            for t in Sun.things_in_garden:
                t.light(angle)
        
class Ant:
    def __init__(self, name):
        self.name = name
        self.body_temperature = 10    # 개미 객체의 초기 체온
        Sun.things_in_garden.append(self)
        
    # 햇빛을 받는 메소드
    def light(self, angle):
        self.body_temperature = self.body_temperature  + 0.1
        print('Body temperature of \'{0}\': {1:4.2f}'
              .format(self.name, self.body_temperature))
                
class Sunflower:
    def __init__(self, name):
        self.name = name
        self.face_angle = 0  # 해바라기 꽃 머리의 초기 방향
        Sun.things_in_garden.append(self)

    # 햇빛을 받을 때마다 해 방향으로 꽃 머리를 돌림 
    def light(self, angle):
        self.face_angle = angle
        print('Face angle of \'{}\': {}’
            .format(self.name, self.face_angle))

class Tree:
    def __init__(self, name, height):
        self.name = name
        self.height = height # 나무의 초기 높이
        Sun.things_in_garden.append(self)

    # 햇빛을 받을 때마다 0.01 cm씩 키가 자람    
    def light(self, angle):
        self.height = self.height + 0.01
        print('Height of \'{0}\': {1:6.2f}'.format(self.name, self.height))

if (__name__ == '__main__'):
    # Sun 객체 생성
    sun = Sun()

    # 정원의 객체들 생성
    ant1 = Ant('ant1')
    ant2 = Ant('ant2')
    tree1 = Tree('tree1', 200)
    tree2 = Tree('tree2', 150)
    sunflower = Sunflower('sunflower1')

    # sun 객체는 동에서 떠서 서쪽으로 질 때까지 정원의 모든 객체들에게 햇빛 보냄
    sun.circle()
