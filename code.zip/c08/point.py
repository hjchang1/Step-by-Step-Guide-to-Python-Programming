class Point:
    def __init__(self):
        self.xPos = 0
        self.yPos = 0

def mov(self, x, y):
    self.xPos = x
    self.yPos = y

Point.move = mov # 클래스 외부에서 정의된 함수 mov로 인스턴스 메소드 move를 정의

p1 = Point() # 좌표 (0, 0)
p1.move(10, 20)
print(p1.xPos, p1.yPos) # 10 20 출력
