# sample.py
class Sample:
    def sum(self, *args):
        r = 0
        for i in args:
            r = r + i

        return r
    

s = Sample()

print(s.sum(1, 2)) # 3
print(s.sum(1.0, 2.0)) # 3.0
print(s.sum(1, 2, 3)) # 6
