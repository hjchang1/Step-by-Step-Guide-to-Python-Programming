# sunflower.py 
class SunFlower:
    total_sunflowers = 0 # SunFlower 클래스의 클래스 변수 total_sunflowers

    def __init__(self, name):
        self.name = name # SunFlower 객체의 인스턴스 변수 name
        self.head_angle = 0 # SunFlower 객체의 인스턴스 변수 head_angle
        SunFlower.total_sunflowers = SunFlower.total_sunflowers + 1

    @classmethod
    def print_total(cls):
        print('cls: {}'.format(cls)) # cls는 항상 클래스를 참조
        print('Total sunflowers = %d' % cls.total_sunflowers)
   
    def light(self, sun_angle):
        '''메시지를 받을 때마다 꽃 머리를 sun_angle로 돌린다'''
        self.head_angel = sun_angle
        print('SunFlower 객체 \"{}\"의 light({}) 메소드가 호출됨.'
              .format(self.name, sun_angle))

    @staticmethod
    def show_time(hour, minute):
        print('{}시 {}분'.format(hour, minute))

if (__name__ == '__main__'):
    # 생성자의 호출
    sunflower1 = SunFlower('sunflower1')
    sunflower2 = SunFlower('sunflower2')

    # 클래스 메소드의 호출
    SunFlower.print_total()
    sunflower1.print_total()

    # 인스턴스 메소드의 호출
    sunflower1.light(31)
    sunflower2.light(32)
    SunFlower.light(sunflower1, 33) # 

    # 정적 메소드의 호출
    SunFlower.show_time(12, 30)
    sunflower1.show_time(11, 30)

