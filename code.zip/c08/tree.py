# tree.py
class Tree:
    '''
    생성자와 클래스 변수 total_trees가 정의된 Tree 클래스
    '''
    total_trees = 0 # 생성된 Tree 객체들의 총 수를 표현하기 위한 클래스 변수
    def __init__(self, height):
        self.height = height # 나무의 높이를 표현하기 위한 인스턴스 변수
        # Tree 인스턴스를 생성할 때마다 total_trees는 1씩 증가
        Tree.total_trees = Tree.total_trees + 1 

t1 = Tree(500) # Tree 객체 t1 생성
t2 = Tree(300)

t2.color = 'GREEN'

print('Tree 클래스의 속성들:', Tree.__dict__)
print('Tree 클래스의 인스턴스 t1의 인스턴스 변수들:', t1.__dict__)
print('Tree 클래스의 인스턴스 t2의 인스턴스 변수들:', t2.__dict__)
