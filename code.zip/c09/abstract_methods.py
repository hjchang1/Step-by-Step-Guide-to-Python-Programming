# abstract_methods.py
import abc

class X (metaclass=abc.ABCMeta):
    # 추상 인스턴스 메소드
    @abc.abstractmethod
    def abstract_instance_method(self):
        pass

    # 추상 클래스 메소드
    @classmethod
    @abc.abstractmethod
    def abstract_class_method(cls):
        pass

    # 추상 정적 메소드
    @staticmethod
    @abc.abstractmethod
    def abstract_static_method():
        pass
