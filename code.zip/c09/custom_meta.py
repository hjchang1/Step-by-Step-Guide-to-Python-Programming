# custom_meta.py
class MyMeta(type):   
    def __call__(cls, *args, **kwargs):
        print('MyMeta __call__()')
        return super().__call__(*args, **kwargs)

class Foo(metaclass=MyMeta):
    def __new__(cls):
        print('Foo __new__()')
        return super().__new__(cls)
       
    def __init__(self):
        print('Foo __init__()')

print('*****************')
foo = Foo() # 여기서 MyMeta.__call__() 이 호출됨
