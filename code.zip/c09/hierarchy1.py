# hierarchy1.py
class Mammal:
    legs = 4
    def move(self):
        print('A mammal moves.')
	
class Dog (Mammal):
    def cry(self):
        print('Bawwow!')

class Cat (Mammal):
    def cry(self):
        print('Mewmew!')

class Poodle (Dog):
    pass

poodle1 = Poodle()

poodle1.cry()
poodle1.move()
