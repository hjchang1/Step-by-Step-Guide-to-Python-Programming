# hierarchy2.py
class Animal (object):
    def move(self):
        print('An animal moves.')
    
class Mammal (Animal):
    pass
	
class Fish (Animal):
    def move(self):
        print('A fish swims.')

class Whale (Mammal, Fish):
    pass

whale1 = Whale()
whale1.move()
