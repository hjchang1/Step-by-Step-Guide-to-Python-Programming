# hierarchy3.py
class Animal:
    totals = 0; # Animal 객체의 총수

    def __init__(self, name):
        self.name = name
        Animal.totals =  Animal.totals + 1
      
    def move(self, speed):
        print('Animal \'{}\' moves at a speed of {} mpm.'
            .format(self.name, speed))

class Dog (Animal):
    def __init__(self, name):
        super().__init__(name) # Animal 클래스의 생성자 호출
        self.skills = [] # 인스턴스 변수 skills
        
    def move(self, speed):
        print('Dog \'{}\' runs at a speed of {} mpm.'
            .format(self.name, speed))

a1 = Animal('a1')
fido = Dog('fido')

print(Animal.totals) # 2

a1.move(100)
fido.move(120)
