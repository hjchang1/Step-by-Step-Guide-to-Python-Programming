# implementation_of_abstract_method.py
import abc

# 추상 메소드를 가지고 있으므로 추상 클래스
class Polygon (metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def area(self):
        pass

class Rectangle(Polygon):
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def area(self):
        return (self.width * self.height)

r = Rectangle(10, 20)
print('area = ', r.area())
