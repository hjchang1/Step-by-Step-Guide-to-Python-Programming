# mro_whale.py
class Animal (object):
    def move(self):
        print('An animal moves.')
    
class Mammal (Animal):
    pass
	
class Fish (Animal):
    def move(self):
        print('A fish swims.')

class Whale (Mammal, Fish):
    pass

print('MRO of Whale class:', Whale.__mro__) # Whale 클래스의 MRO 출력

whale1 = Whale()
whale1.move()
