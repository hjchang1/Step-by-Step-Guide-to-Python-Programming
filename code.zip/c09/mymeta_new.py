# mymeta_new.py
class MyMeta(type):
    def __new__(cls, name, bases, dct):
        x = super().__new__(cls, name, bases, dct)
        x.classvar = 100
        return x

class Foo(metaclass=MyMeta):
    pass

print(Foo.classvar) # 100
