#polygon.py
import abc

class Polygon (metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def area(self):
        pass
