# singleton.py
# singleton 패턴을 구현하는 메타 클래스
class Singleton(type):
    def __call__(cls, *args, **kwargs):
        if (not hasattr(cls, 'instance')):
            cls.instance = super().__call__(*args, **kwargs)
        return cls.instance

class MyClass(metaclass=Singleton):
    pass

a = MyClass()
b = MyClass()
c = MyClass()

print(a == b)
print(b == c)

