# super.py
class X:
    def g(self):
        print('X의 g()가 호출됨')

class Y(X):
    def g(self):
        print('Y의 g()가 호출됨')

    def test(self):
        super(Y, self).g() # Y의 슈퍼 클래스 X의 인스턴스 메소드 g() 호출
        self.g() # 클래스 Y 자신의 메소드 g() 호출

y1 = Y()
y1.test()
