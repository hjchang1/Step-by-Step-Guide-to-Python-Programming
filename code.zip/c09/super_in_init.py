# super_in_init.py
class A:
    def __init__(self):
        super().__init__() # object의 생성자 호출. 아무런 출력이 없다.
        print('A의 생성자 호출됨')
        self.a = 1

class B(A):
    def __init__(self):
        super().__init__() # super(B, self).__init__()
        print('B의 생성자 호출됨')
        self.b = 2
 
class C(A):
    def __init__(self):
        super().__init__() # super(C, self).__init__()
        print('C의 생성자 호출됨');
        self.c = 3
        
class D(B, C):
    def __init__(self):
        super().__init__() # super(D, self).__init__()
        print('D의 생성자 호출됨');
        self.d = 4

print(D.__mro__) # (D, B, C, A, object)
print(C.__mro__) # (C, A, object)
print(B.__mro__) # (B, A, object)
print(A.__mro__) # (A, object)

d1 = D()
