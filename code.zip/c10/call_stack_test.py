# call_stack_test.py
def g():
    print('g()가 호출됨')

def f():
    print('f()가 호출됨')
    g()
 
f()
