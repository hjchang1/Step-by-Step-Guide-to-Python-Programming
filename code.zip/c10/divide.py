# divide.py
x = int(input('숫자1: '))
y = int(input('숫자2: '))

result = None
try:
    result = x/y
finally:
    print('finally 블록 수행.')

print('result:', result)
