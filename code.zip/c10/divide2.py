# divide2.py
x = int(input('숫자1: '))
y = int(input('숫자2: '))

def divide(x, y):
    try:
        result = x/y
        return result
    finally:
        print('finally 블록 수행.')

print('divide({}, {}): {}'.format(x, y, divide(x, y)))
