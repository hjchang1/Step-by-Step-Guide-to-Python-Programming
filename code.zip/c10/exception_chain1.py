# exception_chain1.py 
# g()에서 예외가 발생하고 g()에서 처리 

def g(file_name):
    try:
        file1 = open(file_name, 'r', encoding='utf-8')
        content = file1.read()
        print(content)
        file1.close()
    except FileNotFoundError:
        print('g() 자체에서 g()에서 발생한 FileNotFoundError 처리')
        
def f(file_name):
    print('Function f({}) is called!'.format(file_name))
    g(file_name)

f('not_exist.txt')

