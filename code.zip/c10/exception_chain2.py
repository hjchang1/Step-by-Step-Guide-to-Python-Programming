# exception_chain2.py 
# g()에서 예외가 발생하고 f()에서 처리 

def g(file_name):
    file1 = open(file_name, 'r', encoding='utf-8')
    content = file1.read()
    print(content)
    file1.close()

def f(file_name):
    print('Function f({}) is called!'.format(file_name))
    try:
        g(file_name)
    except FileNotFoundError:
        print('f()에서 g()에서 발생한 FileNotFoundError 예외 처리' )
        
f('not_exist.txt')
