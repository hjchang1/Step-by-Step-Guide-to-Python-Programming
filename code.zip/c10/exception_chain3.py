# exception_chain3.py
# g()에서 예외가 발생하고 __main__ 모듈에서 처리

def g(file_name):
    open(file_name, 'r')
    content = f.read()
    print(content)
    f.close()

def f(file_name):
    print('Function f({}) is called!'.format(file_name))
    g(file_name)
        
try:
    f('not_exist.txt')
except FileNotFoundError:
    print('__main__ 모듈 수준에서 g()에서 발생한 FileNotFoundError 처리' )
