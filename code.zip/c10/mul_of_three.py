# mul_of_three.py 
def multiple_of_three(x):
    if (isinstance(x, int)): # x가 정수이면
        return ((x % 3) == 0) 
    else:
        raise TypeError()

print(multiple_of_three(99)) # True
print(multiple_of_three(100)) # False 
print(multiple_of_three('this')) # TypeError 예외 발생
print('end')
