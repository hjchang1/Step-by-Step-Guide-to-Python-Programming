# multiple_except.py 
class ExceptionA(Exception):
    pass

class ExceptionB (ExceptionA):
    pass

class ExceptionC (ExceptionB):
    pass

for c in [ExceptionA, ExceptionB, ExceptionC]:
    try:
        raise c() # 예외 객체를 발생시킨다.
    except ExceptionC: # ExceptionC 처리 가능
        print('ExceptionC!')
    except ExceptionB: # ExceptionB 처리가능
        print('ExceptionB!')
    except ExceptionA: # ExceptionA 처리가능
        print('ExceptionA!')
