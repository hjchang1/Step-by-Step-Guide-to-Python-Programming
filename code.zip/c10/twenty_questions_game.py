# twenty_questions_game.py 
import random

class ValueSizeError(Exception):
   ''' Base class for other exceptions'''
   pass

class ValueTooSmallError(ValueSizeError):
   '''Raised when the input value is too small'''
   pass

class ValueTooLargeError(ValueSizeError):
   '''Raised when the input value is too large'''
   pass


# 숫자를 추측하여 맞추기
#number = int(random.uniform(1, 101)) # 1에서 100사이의 난수 발생
number = random.randrange(1, 101)
print(number)

print('1에서 100사이에 있는 숫자를 맞추세요.')

count = 0
while True:
   count = count + 1
   try:
       i_num = int(input('숫자를 입력하세요: '))
       if i_num < number:
           raise ValueTooSmallError
       elif i_num > number:
           raise ValueTooLargeError
       else:
           break
   except ValueTooSmallError:
       print('너무 작은 숫자입니다. 더 큰 숫자를 입력하세요.\n')
   except ValueTooLargeError:
       print('너무 큰 숫자입니다. 더 작은 숫자를 입력하세요.\n')
   except ValueError:
       print('숫자가 아닙니다. 숫자를 입력하세요.\n') 

print('축하합니다. {}번 만에 숫자를 맞추셨습니다.'.format(count))
